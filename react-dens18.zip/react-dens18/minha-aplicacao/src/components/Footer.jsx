function Footer() {
  return (
    <footer>
      <p>Desenvolvido por mim - 2026</p>
    </footer>
  );
}

export default Footer;