function Lista(props) {
  return (
    <div>
      <h2>Minha lista de tecnologias</h2>

      <ul>
        {props.itens.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

export default Lista;