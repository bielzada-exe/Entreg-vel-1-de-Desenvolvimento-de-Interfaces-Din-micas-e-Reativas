function Header() {
  return (
    <header>
      <h1>Minha Primeira Aplicação React</h1>
      <p>Aprendendo React com componentes!</p>
    </header>
  );
}

export default Header;