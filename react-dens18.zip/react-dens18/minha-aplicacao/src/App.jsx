import Header from "./components/Header";
import Footer from "./components/Footer";
import Card from "./components/Card";
import Lista from "./components/Lista";
import "./App.css";

function App() {
  const tecnologias = [
    "HTML",
    "CSS",
    "JavaScript",
    "React"
  ];

  return (
    <div className="container">
      <Header />

      <main>
        <Card
          titulo="Aprendendo React"
          descricao="Este é meu primeiro projeto utilizando componentes funcionais."
        />

        <Lista itens={tecnologias} />
      </main>

      <Footer />
    </div>
  );
}

export default App;