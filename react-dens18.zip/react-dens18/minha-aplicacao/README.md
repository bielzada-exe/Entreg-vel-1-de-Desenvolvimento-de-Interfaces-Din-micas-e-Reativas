## Reflexão – Primeira Aplicação React

## 1. Explique a diferença entre a abordagem imperativa (JavaScript puro/manipulação do DOM) e a declarativa (React).

A abordagem imperativa consiste em dar instruções passo a passo ao JavaScript para modificar os elementos da página, utilizando a manipulação do DOM.

Já a abordagem declarativa, utilizada pelo React, permite descrever como queremos que a interface apareça, deixando o React responsável por atualizar os elementos quando necessário.

## 2. Por que o Virtual DOM otimiza a performance?

O Virtual DOM é uma representação virtual da página. Quando acontece alguma alteração, o React compara a versão anterior com a nova e identifica quais elementos precisam ser atualizados. Dessa forma, evita alterações desnecessárias no DOM real, tornando a atualização da página mais eficiente.